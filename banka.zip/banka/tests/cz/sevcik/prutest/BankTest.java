package cz.sevcik.prutest;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

public class BankTest {
    private Bank bank;

    private Customer c1,c2,c3,c4, duplicateC;
    private Account a1, a2, a3, a4, duplicateA, withoutAccountType;


    @BeforeEach
    public void setUp()
    {
        bank = new Bank();

        c1 = new Customer("1","1@lok.cz","pepa");
        c2 = new Customer("2","2@lok.cz","dan");
        c3 = new Customer("3","3@lok.cz","ana");

        duplicateC = new Customer("1","1@lok.cz","pepa");

        Account a1 = new Account("CZ65 0800 0000 1920 0014 5399", AccountType.CURRENT_ACCOUNT, c1 , 0 );
        Account a2 = new Account("CZ65 0800 0000 1920 0014 5391", AccountType.SAVING_ACCOUNT, c2 , 0 );
        a2.setSuspended(true);
        Account a3 = new Account("CZ65 0800 0000 1920 0014 5392", AccountType.CURRENT_ACCOUNT, c3 , 0 );

        duplicateA = new Account("CZ65 0800 0000 1920 0014 5399", AccountType.CURRENT_ACCOUNT, c1 , 0 );
    }


    @Test
    public void testAddAccount(){
        assertTrue(bank.addAccount(a1));
        assertFalse(bank.addAccount(a1));
    }


}
