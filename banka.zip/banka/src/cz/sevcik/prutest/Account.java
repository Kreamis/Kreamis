package cz.sevcik.prutest;

import java.util.Objects;

public class Account {
        private int authorisedOverdraft;
        private double balance;
        private Customer holder;
        private String iban;
        private boolean suspended;
        private AccountType type;

       public Account(String iban, AccountType type){
           this.iban = iban;
           this.type = type;
       }
       public Account(String iban, AccountType type, Customer holder){
        this.iban = iban;
        this.type = type;
        this.holder = holder;
    }
    public Account(String iban, AccountType type, Customer holder, int authorisedOverdraft){
        this.iban = iban;
        this.type = type;
        this.holder = holder;
        this.authorisedOverdraft = authorisedOverdraft;
    }


    public void setAuthorisedOverdraft(int authorisedOverdraft) {
        this.authorisedOverdraft = authorisedOverdraft;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setHolder(Customer holder) {
        this.holder = holder;
    }



    public void setSuspended(boolean suspended) {
        this.suspended = suspended;
    }

    public void setType(AccountType type) {
        this.type = type;
    }

    public int getAuthorisedOverdraft() {
        return authorisedOverdraft;
    }

    public double getBalance(Account account) {
        return balance;
    }

    public Customer getHolder() {
        return holder;
    }

    public String getIban() {
        return iban;
    }

    public boolean isSuspended() {
        return suspended;
    }

    public AccountType getType() {
        return type;
    }

    double deposit(double deposit){
           return 0;
    }

    public double withdraw(double withdrawal){
        return balance;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return authorisedOverdraft == account.authorisedOverdraft && Double.compare(account.balance, balance) == 0 && suspended == account.suspended && Objects.equals(holder, account.holder) && Objects.equals(iban, account.iban) && type == account.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(authorisedOverdraft, balance, holder, iban, suspended, type);
    }

    @Override
    public String toString() {
        return "Account{" +
                "authorisedOverdraft=" + authorisedOverdraft +
                ", balance=" + balance +
                ", holder=" + holder +
                ", iban='" + iban + '\'' +
                ", suspended=" + suspended +
                ", type=" + type +
                '}'+
                "\n";
    }


}
