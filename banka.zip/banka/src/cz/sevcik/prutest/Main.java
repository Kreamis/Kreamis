package cz.sevcik.prutest;

public class Main {
        public static void main(String[] args){
            Bank bank = new Bank();


            Customer c1 = new Customer("1","1@lok.cz","pepa");
            Customer c2 = new Customer("2","2@lok.cz","dan");
            Customer c3 = new Customer("3","3@lok.cz","ana");
            Account a1 = new Account("CZ65 0800 0000 1920 0014 5399", AccountType.CURRENT_ACCOUNT, c1 , 0 );
            Account a2 = new Account("CZ65 0800 0000 1920 0014 5391", AccountType.SAVING_ACCOUNT, c2 , 0 );
            Account a3 = new Account("CZ65 0800 0000 1920 0014 5392", AccountType.CURRENT_ACCOUNT, c3 , 0 );
            bank.addAccount(a1);
            bank.addAccount(a2);
            bank.addAccount(a3);
            a1.setSuspended(true);
            a2.setBalance(22);

            System.out.println(bank.getAllAccounts());


        }
}
