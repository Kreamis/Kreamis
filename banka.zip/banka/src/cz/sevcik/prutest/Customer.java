package cz.sevcik.prutest;

import java.util.Objects;

public class Customer {

    private String birthNumber;
    private String email;
    private String name;

    public Customer(String birthNumber, String email, String name) {
        this.birthNumber = birthNumber;
        this.email = email;
        this.name = name;
    }

    public Customer(String birthNumber, String name){
        this.birthNumber = birthNumber;
        this.name = name;

    }

    public String getBirthNumber() {
        return birthNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Customer customer = (Customer) o;
        return Objects.equals(birthNumber, customer.birthNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(birthNumber,name);
    }

}
