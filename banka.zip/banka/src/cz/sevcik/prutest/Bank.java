package cz.sevcik.prutest;

import java.util.*;

public class Bank {
    private Set<Account>accounts = new HashSet<>();

    public Bank(Set<Account> accounts) {
        this.accounts = accounts;
    }

    public Bank() {

    }

    boolean addAccount(Account newAccount){
        if(newAccount == null || newAccount.getType() == null){
            return false;}
        return accounts.add(newAccount);
    }
    public Collection<Account> getAllAccounts() {
        return new HashSet(accounts);
}

}
