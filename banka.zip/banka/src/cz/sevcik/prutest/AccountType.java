package cz.sevcik.prutest;

public enum AccountType {
    CURRENT_ACCOUNT, SAVING_ACCOUNT;

    AccountType() {
    }

    public static AccountType valueOf() {
        return valueOf();
    }

    public static AccountType[] value(){
        for (AccountType c : AccountType.values())
        System.out.println(c);
        return values();
    }

}
