import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

public class GameTest
{
    private Game game1;

    @BeforeEach
    public void setUp()
    {
        game1 = new Game(78);
    }

    @Test
    public void testGuess()
    {
        assertEquals("Hra již skončila.", game1.guess(40));
        game1.startNewGame(10);
        
        assertEquals("Tajné číslo je větší.", game1.guess(25));
        assertEquals("Tajné číslo je menší.", game1.guess(75));
        
        assertEquals("Tajné číslo je větší.", game1.guess(35));
        assertEquals("Tajné číslo je menší.", game1.guess(65));
        
        assertEquals("Tajné číslo je větší.", game1.guess(25));
        
        assertEquals("Tip mimo povolený interval.", game1.guess(-1000));
        assertEquals("Tip mimo povolený interval.", game1.guess(1000));
        
        assertEquals("Tip mimo povolený interval.", game1.guess(-1));
        assertEquals("Tip mimo povolený interval.", game1.guess(100));
        
        assertEquals("Tajné číslo je větší.", game1.guess(0));
        assertEquals("Tajné číslo je menší.", game1.guess(99));
        
        assertEquals("Uhodl(a) jsi.", game1.guess(50));
        
        assertEquals("Hra již skončila.", game1.guess(40));
        assertEquals("Hra již skončila.", game1.guess(50));
    }

    @Test
    public void testGetGuessCount()
    {
        assertEquals(0, game1.getGuessCount());
        game1.startNewGame(10);
        
        assertEquals(0, game1.getGuessCount());
        
        game1.guess(25);
        assertEquals(1, game1.getGuessCount());
        game1.guess(75);
        assertEquals(2, game1.getGuessCount());
        
        game1.guess(35);
        assertEquals(3, game1.getGuessCount());
        game1.guess(65);
        assertEquals(4, game1.getGuessCount());
        
        game1.guess(25);
        assertEquals(5, game1.getGuessCount());
        
        game1.guess(-1000);
        assertEquals(5, game1.getGuessCount());
        game1.guess(1000);
        assertEquals(5, game1.getGuessCount());
        game1.guess(-1);
        assertEquals(5, game1.getGuessCount());
        game1.guess(100);
        assertEquals(5, game1.getGuessCount());

        game1.guess(0);
        assertEquals(6, game1.getGuessCount());
        game1.guess(99);
        assertEquals(7, game1.getGuessCount());
        
        game1.guess(50);
        assertEquals(8, game1.getGuessCount());
        
        game1.guess(40);
        assertEquals(8, game1.getGuessCount());
        game1.guess(50);
        assertEquals(8, game1.getGuessCount());
        
        game1.startNewGame(10);
        assertEquals(0, game1.getGuessCount());
    }

    @Test
    public void testIsGameOver()
    {
        assertTrue(game1.isGameOver());
        game1.startNewGame(10);

        assertFalse(game1.isGameOver());

        game1.guess(25);
        assertFalse(game1.isGameOver());
        game1.guess(75);
        assertFalse(game1.isGameOver());

        game1.guess(35);
        assertFalse(game1.isGameOver());
        game1.guess(65);
        assertFalse(game1.isGameOver());

        game1.guess(25);
        assertFalse(game1.isGameOver());

        game1.guess(-1000);
        assertFalse(game1.isGameOver());
        game1.guess(1000);
        assertFalse(game1.isGameOver());
        game1.guess(-1);
        assertFalse(game1.isGameOver());
        game1.guess(100);
        assertFalse(game1.isGameOver());

        game1.guess(0);
        assertFalse(game1.isGameOver());
        game1.guess(99);
        assertFalse(game1.isGameOver());

        game1.guess(50);
        assertTrue(game1.isGameOver());

        game1.guess(40);
        assertTrue(game1.isGameOver());
        game1.guess(50);
        assertTrue(game1.isGameOver());

        game1.startNewGame(10);
        assertFalse(game1.isGameOver());
    }

    @Test
    public void testStartNewGame()
    {
        HashSet<Integer> secretNumbers = new HashSet<>();

        for (int i = 0; i < 10000; i++) {
            int newSecretNumber = game1.startNewGame(10);

            assertTrue(newSecretNumber >= 0 && newSecretNumber <= 99);

            secretNumbers.add(newSecretNumber);
        }

        assertTrue(secretNumbers.size() > 30);
    }
}
