import java.util.Random;

public class Game implements IGame
{
    private int secretNumber;  // Tajné číslo
    private int guessCount;    // Počet provedených pokusů
    private boolean gameOver;  // Příznak, zda hra již skončila

    private Random generator;  // Generátor pseudonáhodných čísel

    //# Zde je třeba přidat další atributy (maximální počet pokusů, příznak, zda hráč vyhrál atd.).

    public Game()
    {
        gameOver = true;
        generator = new Random();
    }

    public Game(long seed)
    {
        gameOver = true;
        generator = new Random(seed);
    }

    public int startNewGame(int maxGuessCount)
    {
        secretNumber = generator.nextInt(100);  // Vygeneruje náhodné číslo od 0 do 99
        guessCount = 0;
        gameOver = false;

        //# Zde je třeba vhodným způsobem zpracovat nový parametr maxGuessCount.

        return secretNumber;
    }

    public String guess(int guess)
    {
        //# Je třeba upravit herní logiku v této metodě.

        if (gameOver) {
            return "Hra již skončila.";
        }

        if (guess < 0 || guess > 99) {
            return "Tip mimo povolený interval.";
        }

        guessCount++;

        if (guess < secretNumber) {
            return "Tajné číslo je větší.";
        }

        if (guess > secretNumber) {
            return "Tajné číslo je menší.";
        }

        gameOver = true;
        return "Uhodl(a) jsi.";
    }

    public int getGuessCount()
    {
        return guessCount;
    }

    public boolean isGameOver()
    {
        return gameOver;
    }
    
    public boolean isVictorious()
    {
        //# Zde je třeba zjistit, jestli hráč vyhrál (uhodl tajné číslo a nepřekročil při tom maximální počet pokusů), nebo ne.
        return false;
    }
}
